from django.contrib import admin
from django.urls import path
from app.views import home,login,signup,addtodo,signout,deletetodo,change_todo

urlpatterns = [
    path('',home,name='home'),
    path('home/',home,name='home'),
    path('login/',login,name="login"),
    path('signup/',signup),
    path('add-todo/', addtodo),
    path('delete-todo/<int:id>/', deletetodo),
    path('home/delete-todo/<int:id>', deletetodo),
    path('change-status/<int:id>/<str:status>',change_todo),
    path('logout/', signout),
]