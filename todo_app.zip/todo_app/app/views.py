from django.shortcuts import render,redirect
from django.shortcuts import HttpResponse
from .forms import signupform,loginform
from django.contrib.auth import authenticate,login as loginUser,logout
from app.forms import TODOform
from app.models import TODO
from django.contrib.auth.decorators import login_required
@login_required(login_url='login')
def home(request):
    if request.user.is_authenticated:
        user = request.user
        form = TODOform()
        todos= TODO.objects.filter(user=user).order_by('priority')
        return render(request,'index.html',context={'form' :form,'todos':todos})
    
def login(request):
    if request.method =="POST":
        form=loginform(request.POST)
        if form.is_valid():
            cd=form.cleaned_data
            user=authenticate(request,username=cd["username"],password=cd["password"])
            if user is not None:
                if user.is_active:
                    loginUser(request,user)
                    return redirect('home')
                    #return HttpResponse("<h1> Login successfull </h1")
                else:
                    return HttpResponse("<h1> Disable account </h1>")
            else:
                return HttpResponse("<h1> Invalid Login</h1>")
        else:
            form=loginform()
            return render(request,"login.html",{"form":form})
    else:
        form=loginform()
        return render(request,"login.html",{"form":form})
   
def signup(request):
    user_form=signupform(request.POST)
    if user_form.is_valid():
        user_form.save()
        return redirect('login')
    else:
        user_form=signupform()
        return render(request,'signup.html',{'user_form':user_form})
    
@login_required(login_url='login')
def addtodo(request):
    if request.user.is_authenticated:
        user = request.user
        print(user)
        form= TODOform(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            todo=form.save(commit=False)
            todo.user = user
            todo.save()
            print(todo)
            return redirect("home")
        else:
            return render(request,'index.html',context={'form':form})


@login_required(login_url='login')
def deletetodo(request , id):
    TODO.objects.get(pk= id).delete()
    return redirect('home')

@login_required(login_url='login')
def change_todo(request, id, status):
    todo=TODO.objects.get(pk= id)
    todo.status= status
    todo.save()
    return redirect('home')

@login_required(login_url='login')
def signout(request):
    logout(request)
    return redirect('login')
